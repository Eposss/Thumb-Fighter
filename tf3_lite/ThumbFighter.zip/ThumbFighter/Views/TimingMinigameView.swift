import SwiftUI

struct PowerClashView: View {
    let powerClash: PowerClash
    let holdState: HoldState
    let onTap: () -> Void

    private var markerFraction: CGFloat {
        CGFloat((powerClash.progress + 1) / 2)
    }

    private var statusText: String {
        switch holdState {
        case .playerHolding: return "BOT IS PINNED! 👇"
        case .botHolding:    return "YOU'RE PINNED! FIGHT BACK!"
        case .none:          return "POWER STRUGGLE"
        }
    }

    private var statusColor: Color {
        switch holdState {
        case .playerHolding: return Color(hex: "4cff72")
        case .botHolding:    return Color(hex: "ff6b6b")
        case .none:          return .white
        }
    }

    var body: some View {
        ZStack {
            RapidTapView { onTap() }
                .ignoresSafeArea()

            VStack {
                Spacer()

                VStack(spacing: 10) {
                    Text(statusText)
                        .font(.system(size: 18, weight: .black, design: .rounded))
                        .foregroundColor(statusColor)
                        .shadow(color: .black.opacity(0.6), radius: 4)
                        .animation(.easeInOut(duration: 0.2), value: holdState == .none)

                    // Bar: GeometryReader at the top level so ZStack children
                    // all share the same already-known size — no nested readers.
                    GeometryReader { geo in
                        let barW = geo.size.width
                        let markerW: CGFloat = 20
                        let markerX = markerFraction * barW - markerW / 2

                        ZStack(alignment: .leading) {
                            // Track
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color.black.opacity(0.4))
                                .frame(height: 36)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 20)
                                        .strokeBorder(Color.white.opacity(0.15), lineWidth: 1)
                                )

                            // Player fill — width changes with markerX, no animation needed
                            // (the marker moving is enough visual feedback)
                            RoundedRectangle(cornerRadius: 20)
                                .fill(LinearGradient(
                                    colors: [Color(hex: "00e5ff"), Color(hex: "4cff72")],
                                    startPoint: .leading, endPoint: .trailing
                                ))
                                .frame(width: max(0, markerX + markerW / 2), height: 22)
                                .padding(.horizontal, 7)

                            // Bot fill — same, no animation
                            HStack(spacing: 0) {
                                Spacer(minLength: max(0, markerX + markerW / 2 + 14))
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(LinearGradient(
                                        colors: [Color(hex: "ff9900"), Color(hex: "e94560")],
                                        startPoint: .leading, endPoint: .trailing
                                    ))
                                    .frame(height: 22)
                                    .padding(.trailing, 7)
                            }

                            // Static decorations — never change, drawn last
                            Rectangle()
                                .fill(Color.white.opacity(0.4))
                                .frame(width: 2, height: 44)
                                .offset(x: barW / 2 - 1)

                            pinZoneMarker(at: 0.35 * barW, barH: 36)
                            pinZoneMarker(at: 0.65 * barW, barH: 36)

                            // Marker — the only thing that needs to animate
                            Capsule()
                                .fill(Color.white)
                                .frame(width: markerW, height: 48)
                                .overlay(
                                    Capsule().strokeBorder(statusColor.opacity(0.85), lineWidth: 2.5)
                                )
                                .shadow(color: statusColor.opacity(0.8), radius: 8)
                                .offset(x: markerX)
                                .animation(.interactiveSpring(response: 0.15, dampingFraction: 0.8), value: powerClash.progress)
                        }
                    }
                    .frame(height: 48)

                    HStack {
                        Text("YOU")
                            .font(.system(size: 12, weight: .black, design: .rounded))
                            .foregroundColor(Color(hex: "00e5ff"))
                            .shadow(color: .black, radius: 2)
                        Spacer()
                        Text("BOT")
                            .font(.system(size: 12, weight: .black, design: .rounded))
                            .foregroundColor(Color(hex: "e94560"))
                            .shadow(color: .black, radius: 2)
                    }
                }
                .padding(.horizontal, 60)
                .padding(.bottom, 45)
            }
        }
    }

    @ViewBuilder
    private func pinZoneMarker(at x: CGFloat, barH: CGFloat) -> some View {
        Rectangle()
            .fill(Color.white.opacity(0.3))
            .frame(width: 1.5, height: barH)
            .offset(x: x)
    }
}
