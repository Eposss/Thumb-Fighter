import Foundation
import SwiftUI

// GamePhase tracks what state the game is currently in.
enum GamePhase {
    case idle
    case powerClash
    case roundResult(won: Bool)
    case escaped
    case gameOver(won: Bool)
}

// PowerClash holds the live state of a tug-of-war clash.
struct PowerClash {
    var progress: Double = 0
}

// BotLevel defines how hard a specific opponent is.
struct BotLevel {
    let name: String
    let displayName: String
    let botReactionTime: Double
    let botPinchSpeed: Double
}

// The four opponents in order from easiest to hardest.
// BUFFED FOR MULTI-TOUCH MASHING
let gameLevels: [BotLevel] = [
    BotLevel(
        name: "easy",
        displayName: "Baby Thumb 👶",
        botReactionTime: 0.75,
        botPinchSpeed: 0.45
    ),
    BotLevel(
        name: "medium",
        displayName: "Street Brawler 🤜",
        botReactionTime: 0.4,
        botPinchSpeed: 0.85
    ),
    BotLevel(
        name: "hard",
        displayName: "Iron Grip 💪",
        botReactionTime: 0.18,
        botPinchSpeed: 1.5
    ),
    BotLevel(
        name: "expert",
        displayName: "Thumb God 👁️",
        botReactionTime: 0.05,
        botPinchSpeed: 2.3
    )
]

// HoldState tracks who currently has the upper hand during a clash.
// Equatable lets .animation(value:) skip re-renders when the value hasn't actually changed.
enum HoldState: Equatable {
    case none
    case playerHolding
    case botHolding
}
